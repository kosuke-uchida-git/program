#ifndef LIBRARY
#define LIBRARY

#include "linearRegressionExperiment/linearRegressionExperiment.h"

#endif