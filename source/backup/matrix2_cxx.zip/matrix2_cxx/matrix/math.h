#ifndef MATH
#define MATH

#include "header.h"

bool isInteger(const double a);
int sign(const double a);

#endif