#include "linearRegression.h"

LinearRegression *linearRegression_construct(Regression *r, double lasso,
                                             double ridge) {
#ifdef DEBUG
  if (!r) {
    fprintf(stderr, "linearRegression_construct: NULL Regression pointer\n");
    exit(EXIT_FAILURE);
  }
#endif
  LinearRegression *result = malloc(sizeof(LinearRegression));
  if (!result) {
    fprintf(stderr, "linearRegression_construct: malloc failed\n");
    exit(EXIT_FAILURE);
  }
  result->lassoRegularizer = lasso;
  result->ridgeRegularizer = ridge;
  result->bias = 0.0;
  result->coefficient = matrix_construct(1, r->dimension);
  result->intermediate = matrix_construct(r->dataCount, 1);
  result->regression = r;
  return result;
}

void linearRegression_destruct(LinearRegression *l) {
  if (!l) {
    return;
  }
  matrix_destruct(l->coefficient);
  matrix_destruct(l->intermediate);
  free(l);
}

void linearRegression_optimize(LinearRegression *l) {
  // Calculate difference with bias

  // Accelerate
  // int count = 0;

  double difference;
  double tmpBias;
  while (1) {
    tmpBias = l->bias;

    linearRegression_reviseIntermediate(l);
    linearRegression_reviseBias(l);
    difference = fabs(l->bias - tmpBias);

    linearRegression_reviseCoefficient(l, 0.0);
    // Accelerate
    /*
    if (difference > 0.001) {
      count = 0;
      linearRegression_reviseCoefficient(l, 0.0);
    } else {
      count++;
      linearRegression_reviseCoefficient(l, (count - 1.0) / (count + 2.0));
    }*/

    // Check
    // printf("difference1=%.14f\n", difference);
    if (difference < 1.0E-14) {
      break;
    }
  }

  // Calculate difference with bias and coefficient
  /*
  Matrix *tmpCoefficient = matrix_construct(1, 1);
  difference = 1.0;
  while (1) {
    tmpBias = l->bias;
    matrix_copy(tmpCoefficient, l->coefficient);

    linearRegression_reviseIntermediate(l);
    linearRegression_reviseBias(l);

    linearRegression_reviseCoefficient(l, 0.0);
    // Accelerate
    if (difference > 0.001) {
      count = 0;
      linearRegression_reviseCoefficient(l, 0.0);
    } else {
      count++;
      linearRegression_reviseCoefficient(l, (count - 1.0) / (count + 2.0));
    }*/

  /*matrix_subtract(tmpCoefficient, l->coefficient);
  difference = matrix_l1Norm(tmpCoefficient) + fabs(l->bias - tmpBias);

  // Check
  // printf("difference2=%.14f\n", difference);
  if (difference < 1.0E-12) {
    break;
  }
}
matrix_destruct(tmpCoefficient);*/
}

void linearRegression_reviseBias(LinearRegression *l) {
  l->bias = matrix_meanElements(l->intermediate);
}

void linearRegression_reviseCoefficient(LinearRegression *l, double momentum) {
  // revise coefficient_i (i: dimension index)
  for (size_t i = 0; i < l->regression->dimension; i++) {
    double before = l->coefficient->elements[i];
    double numerator = 0.0, denominator = l->ridgeRegularizer;
    // n: data index
    for (size_t n = 0; n < l->regression->dataCount; n++) {
      double tmp = *matrix_element(l->regression->explanatory, n, i);
      // add numerator
      numerator += tmp * (l->intermediate->elements[n] +
                          l->coefficient->elements[i] * tmp - l->bias);
      // add denominator
      denominator += tmp * tmp;
    }

    // lasso regularization
    if (fabs(numerator) > l->lassoRegularizer) {
      numerator -= l->lassoRegularizer * sign(l->coefficient->elements[i]);
    } else {
      numerator = 0.0;
    }

    l->coefficient->elements[i] =
        before + (1.0 + momentum) * (numerator / denominator - before);
  }
}

void linearRegression_reviseIntermediate(LinearRegression *l) {
  // l->intermediate = l->regression->objective - (l->regression->explanatory *
  // l->coefficient ^T);

  // m=l->regression->explanatory * l->coefficient ^T
  Matrix *m = matrix_constructFromMatrix(l->regression->explanatory);
  Matrix *transposedCoefficient = matrix_constructFromMatrix(l->coefficient);
  matrix_transposeVector(transposedCoefficient);
  matrix_product(m, transposedCoefficient);
  matrix_destruct(transposedCoefficient);

  // l->intermediate = l->regression->objective
  matrix_copy(l->intermediate, l->regression->objective);
  // l->intermediate = l->regression->objective-m
  matrix_subtract(l->intermediate, m);

  matrix_destruct(m);
}

void linearRegression_changeData(LinearRegression *l, Regression *r) {
  l->regression = r;
}

double linearRegression_rmse(LinearRegression *l) {
  // Construct
  Matrix *transposedCoefficient = matrix_constructFromMatrix(l->coefficient);
  matrix_transposeVector(transposedCoefficient);
  int dataCount = l->regression->dataCount;
  // biasVector = (l->bias ... l->bias)^T
  Matrix *biasVector = matrix_construct(dataCount, 1);
  for (size_t i = 0; i < dataCount; i++) {
    biasVector->elements[i] = l->bias;
  }

  // prediction =  (l->regression->explanatory * l->coefficient ^T) + biasVector
  Matrix *prediction = matrix_constructFromMatrix(l->regression->explanatory);
  matrix_product(prediction, transposedCoefficient);
  matrix_add(prediction, biasVector);

  // mse = matrix_l2NormSquare(l->regression->objective - prediction) /
  // dataCount
  Matrix *error = matrix_constructFromMatrix(l->regression->objective);
  matrix_subtract(error, prediction);
  double mse = matrix_l2NormSquare(error) / dataCount;

  // rmse = sqrt(mse)
  double rmse = sqrt(mse);

  // Destruct
  matrix_destruct(transposedCoefficient);
  matrix_destruct(biasVector);
  matrix_destruct(prediction);
  matrix_destruct(error);

  return rmse;
}