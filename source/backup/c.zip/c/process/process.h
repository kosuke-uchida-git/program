#ifndef PROCESS
#define PROCESS

#include "../library/library.h"
void process();

#endif