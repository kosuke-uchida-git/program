<Standard Library headers> -> [head] 
-> intArray -> doubleArray -> matrix -> regression -> linearRegression -> linearRegressionExperiment
-> [library] -> [process] -> [main]